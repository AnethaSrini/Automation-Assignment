package sample;
import java.io.File;
//import org.apache.http.NameValuePair
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;
//import com.sun.jna.platform.FileUtils;
/*
Feature: Use the website to find products in the Australian store
So that I can order a shirt
As an Australian customer
I want to be able to find t shirts in my store
Scenario: Search for t shirts in Australian store
Given I want to order a shirt
When I search for yellow t shirts in the Australian store
Then I should see some yellow t shirts
Also I should organise them by 4 in row
*/

//Scenario 2 and 3 In the Australian site user should be able to see yellow t shirts in 4 organised columns


public class s2yellow {

	public static void main(String[] args) throws InterruptedException {
		
		//Please uncommentand add gecko files if problem in running
		//System.setProperty("webdriver.gecko.driver", "C:\\Users\\selenium\\geckodriver.exe");
	
	
		WebDriver driver = new FirefoxDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://www.asos.com");
		//click ok for cookies
		driver.findElement(By.id("btnClose")).click();
		
		
		//selecting as australian customer
		
				driver.findElement(By.xpath("//*[@id='BodyTag']/div[4]/div/footer/div[2]/div[2]/div[2]/ul/li[6]/a/span")).click();
				//driver.findElement(By.cssSelector("a[class='flag.store-9']")).click();
				
				//
				Thread.sleep(2000);
				driver.navigate().refresh();
				
				driver.findElement(By.xpath("//*[@id='localisationMenu']/a/span[2]")).click();
				Thread.sleep(2000);
				Select drpcurrency = new Select(driver.findElement(By.id("currencyList")));
				drpcurrency.selectByVisibleText("$ AUD");
				WebElement webElement = driver.findElement(By.id("txtSearch"));
				webElement.sendKeys("Yellow T-Shirt");
				driver.findElement(By.className("go")).click();
				
				//Then I should find some products
				
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				List<WebElement> lstProductsName=driver.findElements(By.cssSelector("ul > li.product-container.interactions"));
				    	for(WebElement eleDes:lstProductsName){
				    		 				    	
							System.out.println(eleDes.getText());
							String str =eleDes.getText(); 
							if(str.contains("Yellow"))
								
							try{
							System.out.println("Test Passes");
							}
							catch (Throwable e)
							{
							
							System.out.println("Test Failed");	
							}
				    		
							
							    	
				    	}
				    	
				    	
				  //@And Then display in organised 4 columns
				    	driver.findElement(By.xpath("//*[@id='productlist-results']/div/div[3]/p[2]/a[2]")).click();  	
				    	//*[@id="productlist-results"]/div/div[3]/p[2]/a[2]
				    	
				    	
				    	
				    	
					}

}
