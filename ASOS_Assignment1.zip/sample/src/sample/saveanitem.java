package sample;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


/*Feature: Use the website to find shirts
        So that I can order a shirt
        As a customer
        I want to be able to find t shirts
    Scenario: I want to add t shirts to my shopping bag
        Given I want to search for products like tshirts
        When I  add  few products to my shopping bag
        Then I want see my selected products in my shopping bag

 * 
 */
//Scenario 7: Add items to shopping bag


public class saveanitem {
	public static void main(String args[]) throws InterruptedException {
	//System.setProperty("webdriver.gecko.driver", "C:\\Users\\selenium\\geckodriver.exe");
	
 
	WebDriver driver = new FirefoxDriver();
	
	
	
	//@Given Search for products in website
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("http://www.asos.com");
	//click ok for cookies
	driver.findElement(By.id("btnClose")).click();
	WebElement webElement = driver.findElement(By.id("txtSearch"));
	webElement.sendKeys("Purple T-Shirt");
	driver.findElement(By.className("go")).click();
	
	
	
	//@When I add some items to my shopping bag
	driver.findElement(By.linkText("ASOS Longline T-Shirt In Pastel Purple Towelling" )).click();
	//select size of the product
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	Select drpsize = new Select(driver.findElement(By.cssSelector("select[data-id=sizeSelect]")));
	drpsize.selectByIndex(3);
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//*[@id='product-add']/div/a/span[2]")).click();
	Thread.sleep(2000);
	
	
	
	//@Then I should see the selected products in my shopping bag
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//*[@id='miniBagApp']/div/div[1]/a/span[1]")).click();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	//Thread.sleep(2000);
	  
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    int count=0;
	    List<WebElement> webquantity= driver.findElements(By.xpath("//*[@id='bagApp']/div/div/div[1]/div[1]/bag-item-list/ul/li/div/div/div/bag-item-product/div/div/p[2]/span[4]/span[2]/span[1]/span/span[2]"));
	    for(WebElement chk:webquantity){
	    	count++;
	    }
	    System.out.println("Number of items  in bag "+ count );
	   
}
}
